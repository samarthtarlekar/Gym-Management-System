<?php
    define('RAZOR_KEY_ID', 'rzp_test_MRfEcARmYfR43v');
    define('RAZOR_KEY_SECRET', 'MFtjK3XIZ1RzXoE6pZj4ZYRM');
  ?>